/**
 * view package contains the singleton subpackages other contents.
 */
package view.forms;

