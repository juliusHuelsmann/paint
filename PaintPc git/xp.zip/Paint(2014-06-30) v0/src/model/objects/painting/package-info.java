/**
 * Model package, contains the painting model items.
 */
package model.objects.painting;

