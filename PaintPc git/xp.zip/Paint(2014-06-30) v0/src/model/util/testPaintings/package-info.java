/**
 * 
 */
/**
 * @author juliu_000
 *
 */
package model.util.testPaintings;