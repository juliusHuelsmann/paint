/**
 * contains special pens like the pen for selection curve.
 */
package model.objects.pen.special;

