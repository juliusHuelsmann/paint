/**
 * Contains starter.
 */
package start;

