/**
 * model package contains different implementations of pen.
 */
package model.objects.pen;

