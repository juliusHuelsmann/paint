package view.forms.tabs;

/**
 * the workspace tab.
 * @author Julius Huelsmann
 * @version %I%, %U%
 */
public class Workspace {

	//change workspace location
	//default values
		//page
		//hours
		//numbers
		//sizes
}
