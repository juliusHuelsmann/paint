/**
 * Model package containing structure of a linear list.
 */
package model.util.list;

