/**
 * view package contains the JFrame and in subpackages other contents.
 */
package view;

