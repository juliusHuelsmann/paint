package view.forms.tabs;

import javax.swing.JPanel;

/**
 * Panel for the Tab.
 * @author Julius Huelsmann
 * @version %I%, %U%
 */
@SuppressWarnings("serial")
public class Project extends JPanel {

	/*
	 * Tab
	 */
	//name
	//default page values
	//backup settings
	
	//pencil selection | pencil size selection | pencil color selection | 
	//select somethings | special items like graphc etc | copy-paste | 
	//change color of seleciton?
}
