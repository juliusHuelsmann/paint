/**
 * contains the tabs.
 */
package view.forms.tabs;

