//package declaration
package control.util;

//import declarations
import java.awt.Color;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;

import settings.Constants;
import settings.Error;
import start.utils.Utils;
import view.util.VScrollPane;


/**
 * Controller of ScrollPane.
 * 
 * @author Julius Huelsmann
 * @version %I%, %U%
 */
public class CScrollPane 
implements MouseMotionListener, MouseListener, KeyListener {

    /**
     * The view class.
     */
    private VScrollPane view;

    /*
     * interaction values
     */
    
    /**
     * The points where the dragging started, and the starting location
     * of the center JButton.
     */
    private Point pnt_dragStartOnScreen, pnt_centerStartLocation;
    

    /**
     * if the up or down button is pressed in this moment /
     * if a key is pressed in this moment.
     */
    private boolean upDownPressed = false, keyPressed = false;

    /**
     * the amount of pixel to move.
     */
    private final int moveStep = 5;
    
    /*
     * settings values
     */
    
    /**
     * the color RGBS for the JButtons.
     */
    public static final int BORDER_PRESSED_HL_RGB = 173, 
            BORDER_PRESSED_BG_RGB = 109,
            BORDER_PRESSED_CENTER = 211,
            BORDER_RELEASED_HL_RGB = 204, 
            BORDER_RELEASED_BG_RGB = 124;

    /**
     * Constructor save view class.
     * 
     * @param _view the view class.
     */
    public CScrollPane(final VScrollPane _view) {
        this.view = _view;
    }
    
    
    /**
     * Listener does both graphical things:
     * 
     * if the mouse is pressed, the graphical user interface has to be changed;
     * this method changes the background and the border if a button is clicked.
     * 
     * but also starts to move the Component if the up or down buttons
     * is pressed or saves the initializing values for center drag.
     * 
     * @param _event the mousePressed event.
     */
    @Override public final void mousePressed(final MouseEvent _event) {
    
        //the center button is pressed
        if (_event.getSource().equals(view.getJbtn_center())) {

            //update the border
            view.getJbtn_center().setBorder(BorderFactory.createEtchedBorder(
                    new Color(BORDER_PRESSED_HL_RGB, 
                            BORDER_PRESSED_HL_RGB, 
                            BORDER_PRESSED_HL_RGB), 
                            new Color(BORDER_PRESSED_BG_RGB,
                                    BORDER_PRESSED_BG_RGB,
                                    BORDER_PRESSED_BG_RGB)));
            
            //update the background color
            view.getJbtn_center().setBackground(new Color(
                    BORDER_PRESSED_CENTER,
                    BORDER_PRESSED_CENTER,
                    BORDER_PRESSED_CENTER));
            
        } else if (_event.getSource().equals(view.getJbtn_toTop())) {

            //update the border
            view.getJbtn_toTop().setBorder(BorderFactory.createEtchedBorder(
                    new Color(BORDER_PRESSED_HL_RGB, 
                            BORDER_PRESSED_HL_RGB, 
                            BORDER_PRESSED_HL_RGB), 
                            new Color(BORDER_PRESSED_BG_RGB,
                                    BORDER_PRESSED_BG_RGB,
                                    BORDER_PRESSED_BG_RGB)));
            

            //update the icon
            if (view.isVerticalScroll()) {
                view.getJbtn_toTop().setIcon(new ImageIcon(Utils.resizeImage(
                        view.getJbtn_toTop().getWidth(), 
                        view.getJbtn_toTop().getWidth(), "sb/n/tp.png")));
    
            } else {
                view.getJbtn_toTop().setIcon(new ImageIcon(Utils.resizeImage(
                        view.getJbtn_toTop().getWidth(), 
                        view.getJbtn_toTop().getWidth(), "sb/s/tp.png")));
    
            }
        } else if (_event.getSource().equals(view.getJbtn_toBottom())) {
            
            //update the border
            view.getJbtn_toBottom().setBorder(BorderFactory.createEtchedBorder(
                    new Color(BORDER_PRESSED_HL_RGB, 
                            BORDER_PRESSED_HL_RGB, 
                            BORDER_PRESSED_HL_RGB), 
                            new Color(BORDER_PRESSED_BG_RGB,
                                    BORDER_PRESSED_BG_RGB,
                                    BORDER_PRESSED_BG_RGB)));
            
            //update the icon
            if (view.isVerticalScroll()) {
                view.getJbtn_toBottom().setIcon(new ImageIcon(
                        Utils.resizeImage(view.getJbtn_toBottom().getWidth(),
                                view.getJbtn_toBottom().getWidth(),
                                "sb/n/bp.png")));
            } else {
                view.getJbtn_toBottom().setIcon(new ImageIcon(
                        Utils.resizeImage(view.getJbtn_toBottom().getWidth(), 
                                view.getJbtn_toBottom().getWidth(), 
                                "sb/s/bp.png")));
            }
        }
            
        
        //if center save drag start and point of old center position
        //if top or button, let the panel scroll.
        if (_event.getSource().equals(view.getJbtn_center())) {
            
            //set click start point and center start Point
            pnt_dragStartOnScreen = new Point(_event.getXOnScreen(), 
                    _event.getYOnScreen());
            pnt_centerStartLocation = view.getJbtn_center().getLocation();
            
        } else if (_event.getSource().equals(view.getJbtn_toBottom()) 
                || _event.getSource().equals(view.getJbtn_toTop())) {
            
            //set up down pressed
            upDownPressed = true;
            
            
            //start a 'change - location' Thread.
            new Thread() {
                public void run() {
                    try {
                        
                        //change location while upDown is pressed.
                        while (upDownPressed) {
                            Thread.sleep(2);
                            clickEvent(_event);
                        }
                    } catch (InterruptedException exception) {
                        Error.printError(getClass().getSimpleName(), 
                                "mouse pressed", "interrupted.", exception, 
                                Error.ERROR_MESSAGE_PRINT_LESS);
                    }
                }
            } .start();
        }
    }


    /**
     * Mouse dragged for the center button.
     * @param _event the drag event.
     */
    @Override public final void mouseDragged(final MouseEvent _event) {
        
        //drag center button
        if (_event.getSource().equals(view.getJbtn_center())) {
            
            //vertical scroll versus horizontal scroll
            if (view.isVerticalScroll()) {

                int y = (int) (
                        pnt_centerStartLocation.getY() 
                        - pnt_dragStartOnScreen.getY() 
                        + _event.getYOnScreen());
           
                if (y - view.getJbtn_toTop().getHeight() 
                        > view.getJbtn_toBottom().getY() 
                        - view.getJbtn_toTop().getHeight() 
                        - view.getJbtn_center().getHeight()) {
                    
                    y = view.getJbtn_toBottom().getY() 
                            - view.getJbtn_toTop().getHeight() 
                            - view.getJbtn_center().getHeight() 
                            + view.getJbtn_toTop().getHeight();
                } else if (y < view.getJbtn_toTop().getHeight()) {
                    y = view.getJbtn_toTop().getHeight();
                }
                view.getJbtn_center().setLocation(
                        view.getJbtn_center().getX(), y);
            } else {

                int x = (int) (pnt_centerStartLocation.getX() 
                        - pnt_dragStartOnScreen.getX() 
                        + _event.getXOnScreen());
                
                if (x - view.getJbtn_toTop().getWidth()
                        > view.getJbtn_toBottom().getX()
                        - view.getJbtn_toTop().getWidth()
                        - view.getJbtn_center().getWidth()) {
                    x = view.getJbtn_toBottom().getX() 
                            - view.getJbtn_toTop().getWidth()
                            - view.getJbtn_center().getWidth() 
                            + view.getJbtn_toTop().getWidth();
                } else if (x < view.getJbtn_toTop().getWidth()) {
                    x = view.getJbtn_toTop().getWidth();
                }
                
                view.getJbtn_center().setLocation(
                        x, view.getJbtn_center().getY());
                
            }
            refreshA();     
        }
    }



    /**
     * if clicked at at or down button.
     * 
     * @param _event the mouseEvent
     */
    @Override public final void mouseClicked(final MouseEvent _event) {

        //if to button or the top button do click event once.
        if (_event.getSource().equals(view.getJbtn_toBottom()) 
                || _event.getSource().equals(view.getJbtn_toTop())) {
            clickEvent(_event);
        }
    }



    /**
     * reset pressed graphics to normal ones.
     * 
     * @param _event the MouseEvent
     */
    @Override public final void mouseReleased(final MouseEvent _event) {
        
        //reset the center value.
        if (_event.getSource().equals(view.getJbtn_center())) {
            
            //reset border
            view.getJbtn_center().setBorder(
                    BorderFactory.createEtchedBorder(
                            new Color(BORDER_RELEASED_HL_RGB, 
                                    BORDER_RELEASED_HL_RGB, 
                                    BORDER_RELEASED_HL_RGB),
                            new Color(BORDER_RELEASED_BG_RGB, 
                                    BORDER_RELEASED_BG_RGB, 
                                    BORDER_RELEASED_BG_RGB)));
            view.getJbtn_center().setBackground(Color.white);
            
        } else if (_event.getSource().equals(view.getJbtn_toTop())) {

            //reset border
            view.getJbtn_toTop().setBorder(
                    BorderFactory.createEtchedBorder(
                            new Color(BORDER_RELEASED_HL_RGB, 
                                    BORDER_RELEASED_HL_RGB, 
                                    BORDER_RELEASED_HL_RGB),
                            new Color(BORDER_RELEASED_BG_RGB, 
                                    BORDER_RELEASED_BG_RGB, 
                                    BORDER_RELEASED_BG_RGB)));
            
            //reset icon
            if (view.isVerticalScroll()) {
                view.getJbtn_toTop().setIcon(new ImageIcon(Utils.resizeImage(
                        view.getJbtn_toTop().getWidth(), 
                        view.getJbtn_toTop().getWidth(), 
                        Constants.SP_PATH_UP)));
            } else {
                view.getJbtn_toTop().setIcon(new ImageIcon(Utils.resizeImage(
                        view.getJbtn_toTop().getWidth(), 
                        view.getJbtn_toTop().getWidth(),
                        Constants.SP_PATH_LEFT)));
            }
        } else if (_event.getSource().equals(view.getJbtn_toBottom())) {
            
            //reset border
            view.getJbtn_toTop().setBorder(
                    BorderFactory.createEtchedBorder(
                            new Color(BORDER_RELEASED_HL_RGB, 
                                    BORDER_RELEASED_HL_RGB, 
                                    BORDER_RELEASED_HL_RGB),
                            new Color(BORDER_RELEASED_BG_RGB, 
                                    BORDER_RELEASED_BG_RGB, 
                                    BORDER_RELEASED_BG_RGB)));
            
            if (view.isVerticalScroll()) {
                view.getJbtn_toBottom().setIcon(new ImageIcon(
                        Utils.resizeImage(view.getJbtn_toBottom().getWidth(), 
                                view.getJbtn_toBottom().getWidth(), 
                                Constants.SP_PATH_DOWN)));
    
            } else {
                view.getJbtn_toBottom().setIcon(new ImageIcon(
                        Utils.resizeImage(view.getJbtn_toBottom().getWidth(), 
                                view.getJbtn_toBottom().getWidth(), 
                                Constants.SP_PATH_RIGHT)));
            }
        }
        if (_event.getSource().equals(view.getJbtn_toBottom()) 
                || _event.getSource().equals(view.getJbtn_toTop())) {
            
            upDownPressed = false;
        }
    }


    /**
     * {@inheritDoc}
     */
    @Override public final void mouseEntered(final MouseEvent _event) { }

    /**
     * {@inheritDoc}
     */
    @Override public final void mouseExited(final MouseEvent _event) { }


    /**
     * {@inheritDoc}
     */
    @Override public final void mouseMoved(final MouseEvent _event) {

        if (_event.getSource().equals(view.getJpnl_toLocate())) {
            view.requestFocus();
        }
    }

    @Override public final void keyPressed(final KeyEvent _event) {

        keyPressed = true;
        new Thread() {
            public void run() {
                while (view.getJbtn_toBottom().isVisible() && keyPressed) {
                    try {
                        
                        final int keyCodeUp = 38,
                                keyCodeDown = 40,
                                keyCodeLeft = 37,
                                keyCodeRight = 39;
                        Thread.sleep((2 + 2) * 2);
                        
                        //up button and vertical scroll
                        if (_event.getKeyCode() == keyCodeUp
                                && view.isVerticalScroll()) {
                            addYLocation();
                        } else if (_event.getKeyCode() == keyCodeDown
                                && view.isVerticalScroll()) {
                            removeYLocation();
                        } else if (_event.getKeyCode() == keyCodeLeft
                                && !view.isVerticalScroll()) {
                                addXLocation();   
                        } else if (_event.getKeyCode() == keyCodeRight
                                && !view.isVerticalScroll()) {
                            removeXLocation();
                        }
                    } catch (InterruptedException exception) {

                        Error.printError(getClass().getSimpleName(), 
                                "key pressed", "interrupted.", exception, 
                                Error.ERROR_MESSAGE_PRINT_LESS);
                    }
                }
            }
        } .start();
    }



    /**
     * reset key pressed.
     * @param _event the KeyEvent.
     */
    @Override public final void keyReleased(final KeyEvent _event) {
        keyPressed = false;     
    }

    
    /**
     * {@inheritDoc}
     */
    @Override public final void keyTyped(final KeyEvent _event) { }

    
    /**
     * Click event.
     * @param _event the event.
     */
    private void clickEvent(final MouseEvent _event) {
    
        //
        if (_event.getSource().equals(view.getJbtn_toBottom())) {
          
            if (view.isVerticalScroll()) {
    
                removeYLocation();
            } else {
                removeXLocation();
            }
        } else if (_event.getSource().equals(view.getJbtn_toTop())) {
    
            if (view.isVerticalScroll()) {
                addYLocation();
            } else {
                addXLocation();
            }
        }
    }

    
    /**
     * remove x location.
     */
    private void removeXLocation() {
        
        int x = view.getJpnl_toLocate().getX() - moveStep;
        if (x < -view.getJpnl_toLocate().getWidth()
                + view.getJpnl_owner().getWidth()) {
            x = -view.getJpnl_toLocate().getWidth()
                    + view.getJpnl_owner().getWidth();
        }
        
        view.getJpnl_toLocate().setLocation(x, view.getJpnl_toLocate().getY());
        view.recalculateCenterBounds();
    
    }
    
    
    /**
     * increase x location.
     */
    private void addXLocation() {
        
        int x = view.getJpnl_toLocate().getX() + moveStep;
        
        if (x > 0) {
            x = 0;
        }
        view.getJpnl_toLocate().setLocation(x, view.getJpnl_toLocate().getY());
        view.recalculateCenterBounds();
    }
    
    
    
    /**
     * decrease y location.
     */
    private void removeYLocation() {
        
        
        int y = view.getJpnl_toLocate().getY() - moveStep;
        if (y < -view.getJpnl_toLocate().getHeight()
                + view.getJpnl_owner().getHeight()) {
            y = -view.getJpnl_toLocate().getHeight()
                    + view.getJpnl_owner().getHeight();
        }
        view.getJpnl_toLocate().setLocation(view.getJpnl_toLocate().getX(), y);

        view.recalculateCenterBounds();
    }


    /**
     * increase y location.
     */
    private void addYLocation() {
        
        int y = view.getJpnl_toLocate().getY() + moveStep;
        
        if (y > 0) {
            y = 0;
        }
        view.getJpnl_toLocate().setLocation(view.getJpnl_toLocate().getX(), y);
        view.recalculateCenterBounds();
    }

    
    /**
     * refresh because of center.
     */
    private void refreshA() {
        
        final int cent = 100;
        if (view.isVerticalScroll()) {
            int bar100Percent = view.getJbtn_toBottom().getY() 
                    - view.getJbtn_toTop().getHeight()
                    - view.getJbtn_center().getHeight();
            int percentage = Constants.MAX_PERCENTAGE 
                    * (view.getJbtn_center().getY()
                            - view.getJbtn_toTop().getHeight()) / bar100Percent;
            view.getJpnl_toLocate().setLocation(view.getJpnl_toLocate().getX(), 
                    -percentage * (view.getJpnl_toLocate().getHeight() 
                            - view.getJpnl_owner().getHeight()) / cent);
        } else {

            int bar100Percent = view.getJbtn_toBottom().getX() 
                    - view.getJbtn_toTop().getWidth()
                    - view.getJbtn_center().getWidth();
            int percentage = Constants.MAX_PERCENTAGE 
                    * (view.getJbtn_center().getX() 
                            - view.getJbtn_toTop().getWidth()) 
                            / bar100Percent;
            view.getJpnl_toLocate().setLocation(-percentage 
                    * (view.getJpnl_toLocate().getWidth() 
                            - view.getJpnl_owner().getWidth()) / cent, 
                            view.getJpnl_toLocate().getY());
        }
    }
}
