/**
 * package contains setting values for every package and final / static values
 * for language/data paths etc.
 */
package settings;

