/**
 * contains normal pens.
 */
package model.objects.pen.normal;

