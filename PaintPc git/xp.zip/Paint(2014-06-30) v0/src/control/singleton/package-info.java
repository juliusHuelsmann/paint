/**
 * Creates controller classes created on-the-fly (singleton).
 */
package control.singleton;

