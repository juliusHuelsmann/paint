/**
 * Model package for calculating stuff.
 */
package model.util.solveLGS;

